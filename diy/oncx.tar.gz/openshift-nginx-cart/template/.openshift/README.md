The OpenShift `mock` cartridge documentation can be found at:
https://github.com/openshift/origin-server/blob/master/cartridges/openshift-origin-cartridge-mock/README.md

For information about .openshift directory, consult the documentation:
https://github.com/openshift/origin-server/blob/master/documentation/oo_user_guide.adoc#the-openshift-directory
