For information about action hooks, consult the documentation:

https://github.com/openshift/origin-server/blob/master/documentation/oo_user_guide.adoc#action-hooks
